google安卓商店下载次数：500w+
官网有关地址：
服务：www.letsvpn.world
充值：https://www.kdwindlian.xyz/
公司官网：https://www.letsgo-network.com/
项目地址：https://bitbucket.org/letsgo666/letsgogo/src/main/
中转下载链接：https://appshare.onelink.me/7uiT/cd934bda

采用技术为：CDN（cloudfont）+多VPS负载均衡（VPS）
其通过CDN的访问服务达到伪装流量，绕过GFW的目的。
[4.152.45.219:443](https://x.threatbook.com/v5/ip/4.152.45.219)的
52.76.166.240:80
![[Pasted image 20240626114257.png]]
![[Pasted image 20240626114014.png]]
# 动态基本分析：
### 异常TCP链接（国内）
在初步的微步动态下载相关库（驱动）过程中，访问的tcp国内ip有该国内网址。因此在此进行该ip的基本分析。
1.微步动态安装分析中外联国内ip显示如下：110.242.68.4-百度服务ip
![[Pasted image 20240626115341.png]]
2.扫描网关ip后发现多个证书错误403网站-均为网站服务
![[Pasted image 20240626115921.png]]
![[Pasted image 20240626115900.png]]
3.针对110.242.68.4该ip访问被（安全软件拦截），查看证书可得该ip由CDN服务商globalsign颁发
![[Pasted image 20240626153703.png]]
![[Pasted image 20240626153806.png]]
4.后通过APK动态库分析拿到多ip，并进行初步IP分析
180.163.150.161--无服务
![[Pasted image 20240626155408.png]]
110.253.188.231-多服务5.
![[Pasted image 20240626155545.png]]
5.动态分析过程中很多为443伪装流量，初步判断流量通过国内联通、电信等CDN服务借用百度等大量ip访问的服务器做出口使用。
### 软件内网抓包情况---基于骨干网的MDNS
#### 基本原理
每个进入局域网的主机，如果开启了mDNS 服务的话，都会向局域网内的所有主机组播一个消息，我是谁，和我的IP地址是多少。然后其他也有该服务的主机就会响应，也会告诉你，它是谁，它的IP 地址是多少。当然，具体实现要比这个复杂点。

比如，A 主机进入局域网，开启了mDNS 服务，并向mDNS 服务注册以下信息：我提供FTP 服务，我的IP 是192.168.1.101，端口是21。当B 主机进入局域网，并向B 主机的mDNS 服务请求，我要找局域网内FTP 服务器，B主机的mDNS 就会去局域网内向其他的mDNS 询问，并且最终告诉你，有一个IP地址为192.168.1.101 ，端口号是21 的主机，也就是A 主机提供FTP 服务，所以B 主机就知道了A 主机的IP 地址和端口号了。

#### 访问基于内部网的充值系统抓包
##### 基本原理：SSDP（发现服务需求）->mdns(提供服务地址解析)、igmpv3组播特定数据->基于内外提供ipv6提供服务
![[Pasted image 20240626135756.png]]
##### 抓包分析：
内部网址26.26.26.1为本机虚拟网卡ip（26.0.0.0/8网段为美国军事用途地址），但结合tap虚拟网卡和多播地址239.255.255.250和224.0.0.22和ff02::16等内网保留地址，初步判读26.0.0.0的该ip为恶搞性质。
![[Pasted image 20240626151511.png]]
抓包详情
![[lets vpn.pcapng]]
# 静态分析参数

## 基础信息：

### 文件名称

2ee52db4edf06e527dd7bf1f30a2b6ba52353fac8f8ca78647c9f1668b013ffd

### 文件格式

EXEx86

### 文件类型(Magic)

PE32 executable (GUI) Intel 80386, for MS Windows, Nullsoft Installer self-extracting archive

### 文件大小

14.67MB

### SHA256

2ee52db4edf06e527dd7bf1f30a2b6ba52353fac8f8ca78647c9f1668b013ffd

### SHA1

38f1a1d34f00ac31bfceb60d739ecfc464d87b71

### MD5

ac770f1cb8e8190fabc1dac18aeca371

### CRC32

8CDE32AA

### SSDEEP

393216:le2m5Tvm98UwJ5LDYkzGaJfOdFy65fCT33RaKZ7:oxTlLsCGaiyNxak

### TLSH

T1D4F63349AC83FC97C4A78E31D6F1C7F486BAD7278901CE7164A8A725EE713F43829911

### AuthentiHash

D9243FCAAF7F925FD4D1E9C7C0E05F0920EB5A7E3854BF495B31297044DF96C6

### peHashNG

a358933b8b03f35aa6d62f9d138e75bbe584de91021a06e880d603fcf49afbe7

### RichHash

dbbea5de38bb665ba46f5da13ef89ab8

### impfuzzy

48:JBeZv2GaOIzYArO8Altkz+eOxHALlla/5LRFzn7+P9KQJ45EQl/KAEowrSv0WbXy:n+v3aVz0H1Wx94pKsU

### ImpHash

b34f154ec913d2d2c435cbd644e91687

### ICON SHA256

09deeb5ea41ab3a24325c1f8620cb8c2c67ad67bfad0377554bef47352988001

### ICON DHash

d0e0f86cf4dcdccc

### Tags

exe,lang_english,installer,codesign,signed,valid_signature,encrypt_algorithm


# 关键连通性情报
## 文件内ssl证书发放服务商
### 软件内含的关键网址--CDN服务商
http://ocsp.digicert.com

http://ocsp.comodoca.com

http://crt.sectigo.com/SectigoPublicCodeSigningRootR46.p7c0#

http://ocsp.sectigo.com

http://crl.sectigo.com/SectigoPublicCodeSigningRootR46.crl0

https://sectigo.com/CPS0
### ssl服务商为digicert与sectigo均为美国企业
![[Pasted image 20240626121134.png]]
![[Pasted image 20240626121145.png]]

## 支付方式逆向线索
账户信息：LetsGo Network Incorpora Markham 
官网：https://www.letsgo-network.com/
link：https://www.linkedin.com/company/letsgo-network-incorporated
邮箱：[sales@letsgo-network.com](mailto:sales@letsgo-network.com)
### 支付宝（alipay）
12小时链接[https://excashier.alipay.com/standard/auth.htm?auth_order_id=exc_d2c4fd673f704f7caff59e38eed45199]
![[Pasted image 20240626121505.png]]
### 银联
![[Pasted image 20240626121758.png]]
网站中间件（支付中间件）---https://www.kdwindlian.xyz/account需下载EXE通过TAP虚拟网卡链接充值
![[Pasted image 20240626123452.png]]

![[Pasted image 20240626123256.png]]
