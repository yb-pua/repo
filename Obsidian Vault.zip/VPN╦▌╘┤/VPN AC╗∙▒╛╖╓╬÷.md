官网：vpn.ac
邮箱： info@vpn.ac
## 静态分析
### 基础信息
文件名称

f85b8cdc6850c7e8fc4e8c2951433dcb6f8b210e9617e9cd4c9a98f3c884b26a

文件格式

EXEx86

文件类型(Magic)

PE32 executable (GUI) Intel 80386, for MS Windows

文件大小

30.13MB

SHA256

f85b8cdc6850c7e8fc4e8c2951433dcb6f8b210e9617e9cd4c9a98f3c884b26a

SHA1

80e13d4cddf365a4ca214f9c3ad71b205005447b

MD5

9b55ebc51d3b68f5fbc934859ba4f1f0

CRC32

4157E10E

SSDEEP

786432:efRv9L/yV5ge2FR+8ytpBG7juJYrpMnHkNp5Sqo8:epvEsewA/s7juJYUkTro8

TLSH

T19B673377F154A13EDCAB0A7249B3C3405937BA81B91E8C2F43F4055DDFAA8601E3E666

AuthentiHash

89A8C68F1344F61A8B4D955AC58BEC524E32CAAA348EDAFDE5EB93A9EB8EB229

peHashNG

04646040f8a0ed3604e41331bb18535ad4c209b35b2e4f4e5ff7934ae0ddcd93

impfuzzy

48:ukHAxN9RJjD3vF9X1RfOz9O1hr8XNVXGSHAS4Fo/g/RvEj5MlVNb7q/cE:ukH+NbJj7N9X1tOz9Yhr8XbalVNb7CcE

ImpHash

5a594319a0d69dbc452e748bcf05892e

ExpHash

d73fa6148b569741cefe89496aa4d259

ICON SHA256

b22118c3159d96c061e3e6f668cb26f0c679bb96fccd2c788584d3e2a64c4c35

ICON DHash

92e0b496a6cada72

Tags

exe,tls_callback,lang_dutch,installer,codesign,signed,valid_signature,encrypt_algorithm
### 可疑外链
http://schemas.microsoft.com/SMI/2005/WindowsSettings

https://www.ssl.com/repository0

http://cert.ssl.com/SSLcom-SubCA-CodeSigning-RSA-4096-R1.cer0Q

http://ocsps.ssl.com

http://crls.ssl.com/SSLcom-SubCA-CodeSigning-RSA-4096-R1.crl0

http://crls.ssl.com/ssl.com-rsa-RootCA.crl0

ssl进行数字签证服务
### 静态网络链接
进行微步分析后有3个内网的网段地址，初步判断vpn.ac也会通过虚拟网卡形式分摊流量至基于VPN搭建的内部骨干网。
![[Pasted image 20240627113955.png]]
## 动态分析
### 安装
首先便会询问是否安装下载TAP 
![[Pasted image 20240627114709.png]]
安装全流程未排除出来异常下载流量仅捕获到vpnac的部分访问流量
Path: c:\program files (x86)\vpn.ac client\vpnac.exe
Location: 
IP 地址: 81.4.110.170
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 61.41 KB
数据传出: 4.67 KB
首次访问时间: 2024/6/27 11:47:57
最近访问时间: 2024/6/27 11:47:57
主机名称: noapi.xyz

Path: c:\program files (x86)\vpn.ac client\vpnac.exe
Location: 
IP 地址: 45.32.198.116
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 6.62 KB
数据传出: 938 B
首次访问时间: 2024/6/27 11:47:57
最近访问时间: 2024/6/27 11:47:57
主机名称: ipx.ac

![[Pasted image 20240627115029.png]]
### 注册
注册账号过程需充值
![[Pasted image 20240627115806.png]]
![[Pasted image 20240627120135.png]]
通过账单可以看出
基本收款人信息
Pay To
VPN.AC
Cryptolayer SRL
76 Calea Dumbravii Street, Sibiu, 550399, Romania
VAT ID: RO34573525
在国内可以通过，银联+payple账单进行基本溯源谁用了vpn，但通过visa和万事达或者匿名被黑这类信用账号及加密货币将难以溯源。

### 关键信息汇总
支付信息：payple（现阶段已进行身份证+银联）
数字签名：ssl
外联ip：
Path: c:\program files (x86)\vpn.ac client\vpnac.exe
Location: 
IP 地址: 45.32.198.116
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 13.24 KB
数据传出: 1.83 KB
首次访问时间: 2024/6/27 11:47:57
最近访问时间: 2024/6/27 11:53:58
主机名称: ipx.ac

Path: c:\program files (x86)\vpn.ac client\vpnac.exe
Location: 
IP 地址: 81.4.110.170
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 172.84 KB
数据传出: 12.15 KB
首次访问时间: 2024/6/27 11:47:57
最近访问时间: 2024/6/27 12:05:59
主机名称: noapi.xyz

![[Pasted image 20240627121010.png]]
## 异常状态探测
### 杀进程
初始状态为vpn账号登录状态、IP中断状态、DNS解析为零，openvpn进行的进程下有V2RAY等exe文件，进行kill进程操作查看是否有异常流量产出。
![[Pasted image 20240627143217.png]]
![[Pasted image 20240627143303.png]]
![[Pasted image 20240627143451.png]]
#### 杀进程后结果分析
DNS有异常内网链接无法溯源（基于TAP组建的内部通讯网络）
![[Pasted image 20240627143749.png]]
vpn.ac应用程序异常外联ip：81.4.110.170：443
	#whios情况如下
	
inetnum:        81.4.110.0 - 81.4.110.255
netname:        WESERVIT-RAMNODE
descr:          RamNode IP Space
remarks:        ====================================================
remarks:        This IP space belongs to WeservIT
remarks:        This IP space is allocated to RamNode LLC
remarks:        http://RamNode.com
remarks:        Abuse reports to: abuse@routelabel.net
remarks:        ====================================================
country:        NL
admin-c:        RL10468-RIPE
tech-c:         RL10468-RIPE
status:         SUB-ALLOCATED PA
mnt-by:         ROUTELABEL
mnt-routes:     ROUTELABEL
mnt-domains:    ROUTELABEL
created:        2015-05-12T07:49:55Z
last-modified:  2015-05-12T07:49:55Z
source:         RIPE # Filtered

person:         RamNode LLC
address:        555 S. Independence Blvd, Virginia Beach, VA 23462
address:        US
phone:          +7577564028
nic-hdl:        RL10468-RIPE
mnt-by:         ROUTELABEL
created:        2014-12-07T13:12:14Z
last-modified:  2021-04-08T11:12:30Z
source:         RIPE

% Information related to '81.4.108.0/22AS198203'

route:          81.4.108.0/22
descr:          WeservIT Route Object
origin:         AS198203
mnt-by:         ROUTELABEL
created:        2014-03-10T08:51:57Z
last-modified:  2014-03-10T08:51:57Z
source:         RIPE # Filtered

% This query was served by the RIPE Database Query Service version 1.112.1 (BUSA)

![[Pasted image 20240627143939.png]]
### 突然断网
无任何可疑流量出现