主流三种违规外联方式：全流量加密、vpn点对点、流量伪装代理
全流量加密：tor等
vpn点对点：openvpn、WireGuard等
流量伪装代理：伪装https的tls加密流量，现阶段常用常见流量协议异常TCP（Shadowsocks、VMess、Vless等）、伪装https及物联网（Trojan、Hysteria等）；同时会根据加速和反溯源需求进行CDN代理加速。
