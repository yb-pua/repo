用户数量：1000w+
官网有关地址：
官网：https://protonvpn.com/
代码：https://github.com/orgs/ProtonVPN/repositories
邮箱： support@protonvpn.zendesk.com
开发者：Samuele Kaplun--个人项目地址 https://github.com/kaplun
![[Pasted image 20240626142604.png]]
绕过原理：伪装HTTPS流量绕过
## 静态分析
### 基本信息
文件名称

eb37bf757a2613e6b5c0d328e9b27c64902249c510d8883593e83ff289794aa0

文件格式

EXEx86

文件类型(Magic)

PE32 executable (GUI) Intel 80386, for MS Windows

文件大小

75.71MB

SHA256

eb37bf757a2613e6b5c0d328e9b27c64902249c510d8883593e83ff289794aa0

SHA1

be1157341f0fc1d16b572e869519c9adc5b52e9a

MD5

550e43665d52c2788d36412981978f84

CRC32

15BD103E

SSDEEP

1572864:UE8OTLnGaKm1fGChCZ713ueLEV1+ym36Z8bkFYfyxAhm+BsdDq+tl3f1umwQ:aOTSDmQlu28Ag8bkWfuA8ZtlP1TH

TLSH

T1B408335EB2199A7DE6691A32C2B2C2508D377F53B472CE5A63F4351CCF245040E3FA6A

AuthentiHash

A6C311C3161F2453894AC6B2FA6EF57E30052F5704B6AD795EB363B2BFC16954

peHashNG

ac8bc7b9267e34995b4646c1ac2ebd062f04c04399c8ae28af051bd1468504f2

impfuzzy

96:25kH+NbJj7t9X1tOz9Yhr8XbalVNb75krE:c0KX9FwBCI2rNb9kA

ExpHash

d73fa6148b569741cefe89496aa4d259

ICON SHA256

ecfcfa9ff29f87d8e913a26d908eee338b14c5589583277866fe5cf2e5abfeee

ICON DHash

fec0929ccce061b2

Tags

exe,tls_callback,lang_english,installer,codesign,signed,valid_signature,encrypt_algorithm

### 可疑网址：
http://crt.sectigo.com/SectigoPublicCodeSigningRootR46.p7c0#

http://crl.sectigo.com/SectigoPublicCodeSigningRootR46.crl0

http://ocsp.globalsign.com/ca/gstsacasha384g40C

http://ocsp2.globalsign.com/rootr606

https://www.globalsign.com/repository/0

http://schemas.microsoft.com/SMI/2005/WindowsSettings

其中主要为globalsign和sectigo的签名服务

## 动态分析
exe：断网无法分析，有反分析功能
![[Pasted image 20240627093429.png]]
### 登录中-动态访问过程中出现tcp直连
IP：185.159.159.148--为proton公司服务器地址

登录抓取地址：185.159.159.148
![[Pasted image 20240626153126.png]]
![[Pasted image 20240627092225.png]]
### 注册环境--必须付款后才能获得账号
类似于huawei--alicloud--amz等等云服务商注册账号时验证
![[Pasted image 20240627095452.png]]

### 注册过程中的外联ip
185.159.159.0网段，ip查询均为proton--瑞士公司服务器公网ip
![[Pasted image 20240627101011.png]]
## 关键连通性情报
### 证书服务商
sectigo和globalsign两家美国SSL证书服务商，通过这两家服务商签名的https进行基于443的流量伪装绕过
### 支付方式
订阅服务--proton公司
PayPal--软件检测虚拟网卡会自动阻断
![[Pasted image 20240627095218.png]]

