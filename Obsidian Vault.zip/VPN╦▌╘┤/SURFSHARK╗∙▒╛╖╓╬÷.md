用户量：1000W+
官网：https://surfshark.com/
	关键点：普通Google用户在未进行其他绑定VISA、ALIpay或其他支付手段的情况下直接注册便可以获得VPN服务，
![[Pasted image 20240627105821.png]]
VPN服务采用点对点进行服务，提供相应账户密码
![[Pasted image 20240627105517.png]]
特殊服务：提供虚拟电话和短信，用作匿名伪装。
![[Pasted image 20240627105305.png]]

## 静态分析
断网云沙箱环境无法抓到其ip，程序自动中断
![[Pasted image 20240627110000.png]]
### 基本信息
#### 基础信息：
#文件名称
688c2012a7bffd3f0222a29b8a85e2cd7de83a1d748b30cd12e561e6fb04a966

#文件格式

EXEx86

#文件类型(Magic)

PE32 executable (GUI) Intel 80386, for MS Windows

#文件大小

90.04MB

#SHA256

688c2012a7bffd3f0222a29b8a85e2cd7de83a1d748b30cd12e561e6fb04a966

#SHA1

30500a19235614576043473dcdbeeb799db6830c

#MD5

25b3adcfba00c239b02109b9c8e99efb

#CRC32

AA7A7DEC

#SSDEEP

1572864:tsPu5Z0z6r6v9EkzclNejwUyR35ggifh49ayL+L3abCus5A1I64fNgPC/M2V2K7:pRcclV5iC9aLVBfJuC/dB

#TLSH

T111283330725EC52AD56105F0593CABAB911C6E2A0F61E4C7B3CC6D6F6B704CB1636E2B

#AuthentiHash

FE6A8BF8A61D87B9C1D87F7A78931DB717BB737B2370D9025788A60BE43DDE8A

#peHashNG

661bc6cccd142eda12183b3b87a3d33a4c5e0bfb06a7d018b7f3a0251da7d5d5

#RichHash

562b14e247b9d18db25ecf8cd79b632b

#impfuzzy

48:+OUcSpvEdTsQYbbIoH9sUUwrkrha9x7WzCrwYUrUvZk7IKU86Z:+HcSpvEdTsQYgMSzwrkrGx7Wzo7UrWvZ

#ICON SHA256

32275a52742fe56ec45fdd7363c989f5c921e2de63cce4c38115411a43e935ce

#ICON DHash

d1c8f4d0d0f87c9c

#Tags

exe,tls_callback,pdb_path,lang_english,codesign,signed,valid_signature,encrypt_algorithm

### 可疑网址：
http://schemas.microsoft.com/expression/blend/2008

http://ocsp.globalsign.com/ca/gstsacasha384g40C

http://secure.globalsign.com/cacert/gsgccr45evcodesignca2020.crt0?

http://ocsp2.globalsign.com/rootr606

http://ocsp.globalsign.com/codesigningrootr450F

http://schemas.microsoft.com/SMI/2005/WindowsSettings

http://crl.globalsign.com/root-r6.crl0G

http://schemas.microsoft.com/winfx/2006/xaml/presentation

http://schemas.openxmlformats.org/markup-compatibility/2006

http://schemas.microsoft.com/winfx/2006/xaml

https://www.globalsign.com/repository/0

http://secure.globalsign.com/cacert/codesigningrootr45.crt0A

其中主要为globalsign的签名服务

## 动态分析
### 安装过程
外联ip61.159.93.68--甘肃白银电信城域网--下载数据交互
![[Pasted image 20240627101756.png]]
下载传输中
通过171.214.31.9（四川）和42.123.107.4（贵州）两个代理ip传入大量数据
![[Pasted image 20240627102132.png]]![[Pasted image 20240627102313.png]]
#### 安装后统计
#### 主软件ip连接情况
Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 128.242.240.155
数据传入: 0 B
数据传出: 232 B
首次访问时间: 2024/6/27 10:32:02
最近访问时间: 2024/6/27 10:32:02

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 16.162.10.198
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 0 B
数据传出: 219 B
首次访问时间: 2024/6/27 10:32:02
最近访问时间: 2024/6/27 10:32:02
主机名称: ec2-16-162-10-198.ap-east-1.compute.amazonaws.com

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 104.18.11.36
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 3.16 KB
数据传出: 359 B
首次访问时间: 2024/6/27 10:32:02
最近访问时间: 2024/6/27 10:32:02

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 104.18.38.176
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 10.85 KB
数据传出: 3.36 KB
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 3.64.141.91
端口: 1443 (ies-lm)
端口描述: Integrated Engineering Software
数据传入: 268 B
数据传出: 58 B
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: ec2-3-64-141-91.eu-central-1.compute.amazonaws.com

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 172.64.144.115
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 3.15 KB
数据传出: 357 B
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: sir90hl.com

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 172.64.149.80
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 13.45 KB
数据传出: 3.68 KB
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: uymgg1.com

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 1.1.1.1
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 117.22 KB
数据传出: 13.22 KB
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:32:02
主机名称: one.one.one.one

Path: c:\program files (x86)\surfshark\surfshark.exe
Location: 
IP 地址: 4.153.25.42
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 11.99 KB
数据传出: 3.17 KB
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: in.appcenter.ms

![[Pasted image 20240627103608.png]]
#### 服务器连接情况
Path: c:\users\anonymous\desktop\vpn\surfshark\surfsharksetup.exe
Location: 
IP 地址: 18.245.65.219
端口: 80 (http)
端口描述: World Wide Web HTTP
数据传入: 983 B
数据传出: 283 B
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: ocsp.r2m01.amazontrust.com

Path: c:\users\anonymous\desktop\vpn\surfshark\surfsharksetup.exe
Location: 
IP 地址: 18.245.39.64
端口: 80 (http)
端口描述: World Wide Web HTTP
数据传入: 4.21 KB
数据传出: 583 B
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: ocsp.rootg2.amazontrust.com

Path: c:\users\anonymous\desktop\vpn\surfshark\surfsharksetup.exe
Location: 
IP 地址: 108.138.2.10
端口: 80 (http)
端口描述: World Wide Web HTTP
数据传入: 2.78 KB
数据传出: 260 B
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: o.ss2.us

Path: c:\users\anonymous\desktop\vpn\surfshark\surfsharksetup.exe
Location: 
IP 地址: 54.165.254.88
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 5.58 KB
数据传出: 403 B
首次访问时间: 2024/6/27 10:29:02
最近访问时间: 2024/6/27 10:29:02
主机名称: collect.installeranalytics.com

Path: c:\users\anonymous\desktop\vpn\surfshark\surfsharksetup.exe
Location: 
IP 地址: 61.159.93.68
端口: 80 (http)
端口描述: World Wide Web HTTP
数据传入: 11.55 KB
数据传出: 488 B
首次访问时间: 2024/6/27 10:13:52
最近访问时间: 2024/6/27 10:13:52
主机名称: crl.globalsign.com
![[Pasted image 20240627104000.png]]
#### 服务器端链接情况
Path: c:\program files (x86)\surfshark\surfshark.service.exe
Location: 
IP 地址: 4.153.25.42
端口: 443 (https)
端口描述: http protocol over TLS/SSL
数据传入: 12.28 KB
数据传出: 2.49 KB
首次访问时间: 2024/6/27 10:25:59
最近访问时间: 2024/6/27 10:29:02
主机名称: in.appcenter.ms
![[Pasted image 20240627104012.png]]
### 注册过程
支付后进行服务和注册正式账号
![[Pasted image 20240627105107.png]]
同时该软件有虚拟环境监测，容易发生报错
![[Pasted image 20240627110924.png]]
### 关键信息汇总
支付方式--surfshark公司订阅
![[Pasted image 20240627112523.png]]
https签名服务商：globalsign
国内可疑ip：
软件默认外联ip61.159.93.68--甘肃白银电信城域网--下载数据交互
下载传输中
通过171.214.31.9（四川）和42.123.107.4（贵州）两个代理ip传入大量数据
